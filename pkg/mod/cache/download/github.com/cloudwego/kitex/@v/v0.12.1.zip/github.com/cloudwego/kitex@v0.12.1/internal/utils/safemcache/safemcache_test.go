/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package safemcache

import (
	"testing"
	"unsafe"

	"github.com/cloudwego/kitex/internal/test"
)

func TestMallocFree(t *testing.T) {
	// case: normal
	b := Malloc(1)
	test.Assert(t, len(b) == 1)

	h := (*sliceHeader)(unsafe.Pointer(&b))
	test.Assert(t, h.Footer() == footerMagic)

	Free(b)
	test.Assert(t, h.Footer() == 0)

	// case: magic not match
	b = Malloc(1)
	test.Assert(t, len(b) == 1)
	h = (*sliceHeader)(unsafe.Pointer(&b))
	test.Assert(t, h.Footer() == footerMagic)

	h.SetFooter(2)
	Free(b) // it will not work
	test.Assert(t, h.Footer() == 2)
}
