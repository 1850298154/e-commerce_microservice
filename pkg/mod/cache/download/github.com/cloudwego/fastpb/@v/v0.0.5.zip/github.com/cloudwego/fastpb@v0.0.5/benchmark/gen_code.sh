# Copyright 2022 CloudWeGo Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# fastpb
rm -rf ./fastpb_gen && mkdir -p ./fastpb_gen
protoc --go_opt=paths=source_relative --go_out=./fastpb_gen --fastpb_opt=paths=source_relative --fastpb_out=./fastpb_gen -I ./idl/ ./idl/testcase.proto

# gogo
rm -rf ./gogo_gen && mkdir ./gogo_gen
protoc --gogofaster_opt=paths=source_relative --gogofaster_out=./gogo_gen -I ./idl/ ./idl/testcase.proto