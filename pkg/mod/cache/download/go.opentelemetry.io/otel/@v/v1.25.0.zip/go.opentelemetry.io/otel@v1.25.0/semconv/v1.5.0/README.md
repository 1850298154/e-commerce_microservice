# Semconv v1.5.0

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/semconv/v1.5.0)](https://pkg.go.dev/go.opentelemetry.io/otel/semconv/v1.5.0)
